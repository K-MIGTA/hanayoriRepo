package jp.co.sss.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharedShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
