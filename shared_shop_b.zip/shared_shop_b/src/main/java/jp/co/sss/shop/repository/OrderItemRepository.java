package jp.co.sss.shop.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import jp.co.sss.shop.entity.OrderItem;

/**
 * order_itemsテーブル用リポジトリ
 *
 * @author Ikenoue
 */
public interface OrderItemRepository extends JpaRepository<OrderItem, Integer> {

	@Query("SELECT item.id FROM OrderItem oi GROUP BY oi.item.id ORDER BY count(item.id) asc")
	public List<Integer> findByIdOrderQuantityQuery();

	@Query("SELECT item.id FROM OrderItem oi GROUP BY oi.item.id ORDER BY count(item.id) desc")
	public List<Integer> findByIdOrderQuantityDescQuery();

}
