package jp.co.sss.shop.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jp.co.sss.shop.entity.Inqueries;

@Repository
public interface InqueriesRepository extends JpaRepository<Inqueries, Integer> {

	public Page<Inqueries> findAllByOrderByIdDesc(Pageable pageable);

}