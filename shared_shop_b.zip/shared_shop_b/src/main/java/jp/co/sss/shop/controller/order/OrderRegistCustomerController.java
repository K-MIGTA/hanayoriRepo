package jp.co.sss.shop.controller.order;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.bean.BasketBean;
import jp.co.sss.shop.bean.OrderItemBean;
import jp.co.sss.shop.bean.UserBean;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.entity.Order;
import jp.co.sss.shop.entity.OrderItem;
import jp.co.sss.shop.entity.User;
import jp.co.sss.shop.form.AddressForm;
import jp.co.sss.shop.form.OrderForm;
import jp.co.sss.shop.repository.ItemRepository;
import jp.co.sss.shop.repository.OrderItemRepository;
import jp.co.sss.shop.repository.OrderRepository;
import jp.co.sss.shop.repository.UserRepository;
import jp.co.sss.shop.util.PriceCalc;

/**
 * 注文管理
 *
 *  @author 花より漢気
 */
@Controller
public class OrderRegistCustomerController {

	/**
	 * セッション
	 */
	@Autowired
	HttpSession session;

	/**
	 * 注文情報
	 */
	@Autowired
	OrderRepository orderRepository;

	/**
	 * 注文商品情報
	 */
	@Autowired
	OrderItemRepository orderItemRepository;

	/**
	 * 商品情報
	 */
	@Autowired
	ItemRepository itemRepository;

	/**
	 * 会員情報
	 */
	@Autowired
	UserRepository userRepository;

	/**
	 * POSTメソッドを利用してお届け先情報入力画面表示処理
	 *
	 */
	@RequestMapping(path = "/address/input", method = RequestMethod.POST)
	public String addRegistBack(@ModelAttribute AddressForm form, Model model, boolean backFlg) {
		if (!backFlg) {
			UserBean userBean = (UserBean) session.getAttribute("user");
			User user = userRepository.getOne(userBean.getId());

			BeanUtils.copyProperties(user, form);

			model.addAttribute("addressForm", form);

		} else {
			model.addAttribute("addressForm", form);
		}

		return "order/regist/order_address_input";
	}

	/**
	 * POSTメソッドを利用してお支払方法選択画面表示処理
	 * お届け先入力情報確認処理
	 */
	@RequestMapping(path = "/payment/input", method = RequestMethod.POST)
	public String registAdressCheck(@Valid @ModelAttribute AddressForm form, BindingResult result, Model model,  @ModelAttribute OrderForm form2 ) {

		if (result.hasErrors()) {
			return "order/regist/order_address_input";
		}
		return "order/regist/order_payment_input";
	}

	/**
	 * POSTメソッドを利用して注文商品確認画面表示処理
	 * お支払方法入力情報確認処理
	 */
	@RequestMapping(path = "/order/check", method = RequestMethod.POST)
	public String registPayCheck(@Valid @ModelAttribute OrderForm form, BindingResult result, Model model) {

		if (result.hasErrors()) {
			return "order/regist/order_payment_input";
		}

		// 買い物かご商品情報を取得
		List<BasketBean> basket = (List<BasketBean>) session.getAttribute("basket");
		List<OrderItemBean> orderItemBeanList = new ArrayList<OrderItemBean>();
		for (BasketBean basketBean : basket) {
			Item item = itemRepository.getOne(basketBean.getId());
			OrderItemBean orderItemBean = new OrderItemBean();

			orderItemBean.setName(basketBean.getName());
			orderItemBean.setPrice(item.getPrice());
			orderItemBean.setOrderNum(basketBean.getOrderNum());

			//購入時単価の合計値を計算
			//※OrderItemのItemフィールドからgetPriceを利用すると、購入時ではなく現在の単価になってしまう。
			int subtotal = item.getPrice() * basketBean.getOrderNum();

			orderItemBean.setSubtotal(subtotal);

			orderItemBeanList.add(orderItemBean);
		}

		// 合計金額を算出
		int total = PriceCalc.orderItemPriceTotal(orderItemBeanList);

		// 注文情報をViewへ渡す
		model.addAttribute("orderItemBeans", orderItemBeanList);
		model.addAttribute("total", total);

		return "order/regist/order_check";
	}

	/**
	 * 注文商品情報登録完了処理
	 *
	 */
	@RequestMapping(path = "/order/complete", method = RequestMethod.POST)
	public String registOrderCheck(@Valid @ModelAttribute OrderForm form, BindingResult result) {

		if (result.hasErrors()) {
			System.out.println("test");
			return "order/regist/order_check";
		}

		List<BasketBean> baskets = (List<BasketBean>) session.getAttribute("basket");

		UserBean userBean = (UserBean) session.getAttribute("user");

		User user = userRepository.getOne(userBean.getId());

		Order order = new Order();
		order.setAddress(form.getAddress());
		order.setName(form.getName());
		order.setPayMethod(form.getPayMethod());
		order.setPhoneNumber(form.getPhoneNumber());
		order.setPostalCode(form.getPostalCode());
		order.setUser(user);
		orderRepository.save(order);

		for (BasketBean list : baskets) {
			Item item = itemRepository.getOne(list.getId());
			OrderItem orderItem = new OrderItem();
			orderItem.setOrder(order);
			orderItem.setQuantity(list.getOrderNum());
			orderItem.setPrice(item.getPrice());
			orderItem.setItem(item);
			orderItemRepository.save(orderItem);

			item.setStock(item.getStock() - orderItem.getQuantity());
			itemRepository.save(item);
		}

		baskets.clear();

		Map<Integer, Integer> map = (Map<Integer, Integer>) session.getAttribute("mapList");

		map.clear();

		session.setAttribute("baskets", baskets);

		session.setAttribute("mapList", map);

		return "redirect:/order/complete";
	}

	/**
	 * 注文商品情報登録完了処理
	 *
	 */
	@RequestMapping(path = "/order/complete", method = RequestMethod.GET)
	public String registOrderComplete() {
		return "order/regist/order_complete";
	}

}
