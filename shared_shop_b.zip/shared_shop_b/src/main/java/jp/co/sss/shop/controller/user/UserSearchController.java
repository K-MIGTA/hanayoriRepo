package jp.co.sss.shop.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.entity.User;
import jp.co.sss.shop.repository.UserRepository;
import jp.co.sss.shop.util.Constant;

/**
 * 会員管理 検索機能(運用管理者、システム管理者)のコントローラクラス
 *
 * @author 花より漢気
 */
@Controller
public class UserSearchController {
	/**
	 * 会員情報
	 */
	@Autowired
	UserRepository userRepository;

	/**
	 * 会員一覧表示処理
	 *
	 * @param model    Viewとの値受渡し
	 * @param form     会員情報フォーム
	 * @param pageable ページング情報
	 * @return "user/list/user_list" 会員情報一覧表示画面へ
	 */
	@RequestMapping(path = "/search/user/name", method = RequestMethod.POST)
	public String searchUserName(Model model, String name, Pageable pageable) {

		String likeName = "%" + name + "%";

		// 会員情報リストを取得
		Page<User> userList = userRepository.findByNameLikeAndDeleteFlagLike(likeName,Constant.NOT_DELETED, pageable);

		// 会員情報をViewに渡す
		model.addAttribute("pages", userList);
		model.addAttribute("users", userList.getContent());
		model.addAttribute("url", "/user/list");

		return "user/list/user_list";
	}

	/**
	 * 会員一覧表示処理
	 *
	 * @param model    Viewとの値受渡し
	 * @param form     会員情報フォーム
	 * @param pageable ページング情報
	 * @return "user/list/user_list" 会員情報一覧表示画面へ
	 */
	@RequestMapping(path = "search/user/email", method = RequestMethod.POST)
	public String searchUserEmail(Model model, String email, Pageable pageable) {

		String likeEmail = "%" + email + "%";
		// 会員情報リストを取得
		Page<User> userList = userRepository.findByEmailLikeAndDeleteFlagLike(likeEmail, Constant.NOT_DELETED,pageable);

		// 会員情報をViewに渡す
		model.addAttribute("pages", userList);
		model.addAttribute("users", userList.getContent());

		return "user/list/user_list";
	}

	/**
	 * 会員一覧表示処理
	 *
	 * @param model    Viewとの値受渡し
	 * @param form     会員情報フォーム
	 * @param pageable ページング情報
	 * @return "user/list/user_list" 会員情報一覧表示画面へ
	 */
	@RequestMapping(path = "search/user/phone", method = RequestMethod.POST)
	public String searchUserPhone(Model model, String phone , Pageable pageable) {

		String likePhone = "%" + phone +  "%";
		// 会員情報リストを取得
		Page<User> userList = userRepository.findByPhoneNumberLikeAndDeleteFlagLike(likePhone,Constant.NOT_DELETED, pageable);

		// 会員情報をViewに渡す
		model.addAttribute("pages", userList);
		model.addAttribute("users", userList.getContent());

		return "user/list/user_list";
	}
}
