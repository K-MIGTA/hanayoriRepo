package jp.co.sss.shop.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * お気に入り情報のエンティティクラス
 *
 * @author 花より漢気
 */
@Entity
@Table(name = "favorites")
public class Favorite {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_favorite_items_gen")
	@SequenceGenerator(name = "seq_favorite_items_gen", sequenceName = "seq_favorite_items", allocationSize = 1)
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "item_id", referencedColumnName = "id")
	private Item itemId;

	@ManyToOne
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User userId;

	@Column(insertable = false)
	private Integer deleteFlag;

	/**
	 * コンストラクタ
	 */
	public Favorite() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Item getItemId() {
		return itemId;
	}

	public void setItemId(Item itemId) {
		this.itemId = itemId;
	}

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public Integer getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Integer deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

}
