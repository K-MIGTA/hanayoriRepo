package jp.co.sss.shop.controller.user;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.entity.Inqueries;
import jp.co.sss.shop.entity.Questions;
import jp.co.sss.shop.form.ContactForm;
import jp.co.sss.shop.repository.InqueriesRepository;
import jp.co.sss.shop.repository.QuestionsRepository;

/**
	* お問い合わせ記述(非会員)
	*
	* @author 花より漢気
	*/

@Controller
public class ContactDescriptionController {

	@Autowired
	private InqueriesRepository inqueriesRepository;

	@Autowired
	private QuestionsRepository questionsRepository;

	@Autowired
	HttpSession session;

	@RequestMapping(path = "contact", method = RequestMethod.GET)
	public String questionsListSetDropdown(Model model) {
		session.setAttribute("questions", questionsRepository.findAll());

		ContactForm contactForm = new ContactForm();

		model.addAttribute("contactForm", contactForm);
		return "user/contact/user_contact";
	}

	@RequestMapping(path = "contact", method = RequestMethod.POST)
	public String contactInput(ContactForm form) {
		return "user/contact/user_contact";
	}

	@RequestMapping(path = "contact/check", method = RequestMethod.POST)
	public String userContactCheck(@Valid @ModelAttribute ContactForm form, BindingResult result, Model model) {

		// 入力値にエラーがあった場合、お問い合わせ画面に戻る
		if (result.hasErrors()) {
			model.addAttribute("errMessage", "・お問い合わせ内容は必須項目です。１文字以上１５０文字以内で入力してください。");
			return "user/contact/user_contact";
		}

		Questions question = questionsRepository.getOne(form.getId());

		form.setName(question.getName());

		model.addAttribute("contactForm", form);

		return "user/contact/check/user_contact_check";
	}

	@RequestMapping(path = "contact/done", method = RequestMethod.POST)
	public String contactDone(@ModelAttribute ContactForm form) {
		// お問い合わせ情報の生成
		Inqueries inqueries = new Inqueries();

		Questions question = questionsRepository.getOne(form.getId());

		inqueries.setQuestions(question);
		inqueries.setText(form.getText());

		// お問い合わせ情報を保存
		inqueriesRepository.save(inqueries);

		return "redirect:/contact/done";
	}

	@RequestMapping(path = "contact/done", method = RequestMethod.GET)
	public String userContactDoneRedirect() {
		return "user/contact/done/user_contact_done";
	}

}