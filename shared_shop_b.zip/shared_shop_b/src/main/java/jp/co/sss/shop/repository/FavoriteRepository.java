package jp.co.sss.shop.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jp.co.sss.shop.entity.Favorite;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.entity.User;

/**
 * favoritesテーブル用リポジトリ
 *
 * @author System Shared
 */
@Repository

public interface FavoriteRepository extends JpaRepository<Favorite, Integer> {

	public List<Favorite> findByUserIdAndDeleteFlag(User userId, int notDeleted);

	public List<Favorite> findByDeleteFlag(int notDeleted);

	public Favorite findByUserIdAndItemId(User user, Item item);

	public Page<Favorite> findByUserIdAndDeleteFlag(User user, int notDeleted, Pageable pageable);

}