package jp.co.sss.shop.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jp.co.sss.shop.entity.Item;

/**
 * itemsテーブル用リポジトリ
 *
 * @author System Shared
 */
@Repository
public interface ItemRepository extends JpaRepository<Item, Integer> {


	// 商品情報を新着順で検索
	public Page<Item> findByDeleteFlagOrderByInsertDateDesc(int deleteFlag, Pageable pageable);

	public Page<Item> findByCategoryId(int sortType ,Pageable pageable );

	public Page<Item> findById(int id ,Pageable pageable);

	public Page<Item> findByDeleteFlagAndCategoryIdOrderByInsertDateDesc(int notDeleted, int categoryId,
			Pageable pageable);



}
