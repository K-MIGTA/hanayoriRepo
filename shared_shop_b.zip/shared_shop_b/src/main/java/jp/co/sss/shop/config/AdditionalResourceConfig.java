package jp.co.sss.shop.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jp.co.sss.shop.util.Constant;

@Configuration
public class AdditionalResourceConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		//「以下のURLパスがリクエストされたら」、「以下のフォルダのファイルを使用する」という設定
		registry.addResourceHandler(Constant.IMAGE_LOCAL_FOLDER + "**")
				.addResourceLocations(Constant.IMAGE_LOCAL_RESOURCE_LOCATIONS);
	}
}
