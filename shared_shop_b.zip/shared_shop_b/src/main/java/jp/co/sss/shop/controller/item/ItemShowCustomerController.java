package jp.co.sss.shop.controller.item;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.bean.ItemBean;
import jp.co.sss.shop.bean.UserBean;
import jp.co.sss.shop.entity.Favorite;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.entity.User;
import jp.co.sss.shop.repository.FavoriteRepository;
import jp.co.sss.shop.repository.ItemRepository;
import jp.co.sss.shop.repository.OrderItemRepository;
import jp.co.sss.shop.repository.UserRepository;
import jp.co.sss.shop.util.BeanCopy;
import jp.co.sss.shop.util.Constant;

/**
 * 商品管理 一覧表示機能(一般会員用)のコントローラクラス
 *
 * @author SystemShared
 */
@Controller
public class ItemShowCustomerController {
	/**
	 * 商品情報
	 */
	@Autowired
	ItemRepository itemRepository;

	@Autowired
	FavoriteRepository favoriteRepository;

	/**
	 * 商品情報
	 */
	@Autowired
	UserRepository userRepository;

	@Autowired
	OrderItemRepository orderItemRepository;

	/**
	 * セッション管理
	 */
	@Autowired
	HttpSession session;

	@RequestMapping("/login")
	public String searchWithQuery(Model model) {

		return "index";
	}

	/**
	 * トップ画面 表示処理
	 *
	 * @param model    Viewとの値受渡し
	 * @param pageable ページング情報
	 * @return "/" トップ画面へ
	 */
	@RequestMapping(path = "/")
	public String index(Model model, Pageable pageable) {

		List<Integer> lists = orderItemRepository.findByIdOrderQuantityQuery();
		Page<Item> items = itemRepository.findByDeleteFlagOrderByInsertDateDesc(Constant.NOT_DELETED, pageable);

		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(items.getContent());

		for (int id : lists) {
			for (ItemBean bean : itemBeanList) {
				if (bean.getId() == id) {
					itemBeanList.remove(bean);
					break;
				}
			}
		}
		for (int itemId : lists) {
			Item item = itemRepository.getOne(itemId);

			ItemBean bean = new ItemBean();
			bean.setId(item.getId());
			bean.setName(item.getName());
			bean.setPrice(item.getPrice());
			bean.setStock(item.getStock());
			bean.setImage(item.getImage());
			bean.setDescription(item.getDescription());
			bean.setCategoryId(item.getCategory().getId());
			bean.setCategoryName(item.getCategory().getName());

			itemBeanList.add(0, bean);
		}
		model.addAttribute("pages", items);
		model.addAttribute("items", itemBeanList);
		model.addAttribute("url", "/item/list/");

		return "index";
	}

	/**
	 * 商品詳細 表示処理
	 *
	 */
	@RequestMapping(path = "/item/detail/{id}")
	public String itemsDetail(@PathVariable int id, Model model, Pageable pageable) {

		// ログイン中の会員情報を取得
		UserBean userBean = (UserBean) session.getAttribute("user");

		Item item = itemRepository.findById(id).orElse(null);

		model.addAttribute("item", item);
		model.addAttribute("favorite", 0);

		if (userBean != null) {
			User user = userRepository.getOne(userBean.getId());

			List<Favorite> page = favoriteRepository.findByUserIdAndDeleteFlag(user, Constant.NOT_DELETED);

			if (page != null) {
				for (Favorite favorite : page) {
					if (favorite.getItemId() == item) {
						model.addAttribute("favorite", 1);
					}
				}
			}

		}

		return "/item/detail/item_detail";

	}

	/**
	 * カテゴリー検索
	 *
	 */
	@RequestMapping(path = "/item/list/category/{sortType}", method = RequestMethod.GET)
	public String showItemListByCategory(@PathVariable int sortType, int categoryId, Model model, Pageable pageable) {

		Page<Item> items = itemRepository.findByDeleteFlagAndCategoryIdOrderByInsertDateDesc(Constant.NOT_DELETED,
				categoryId, pageable);

		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(items.getContent());

		model.addAttribute("pages", items);
		model.addAttribute("items", itemBeanList);
		model.addAttribute("url", "/item/list/");

		model.addAttribute("sortType", 1);

		session.setAttribute("items", items);
		session.setAttribute("itemBeans", itemBeanList);
		session.setAttribute("search", 1);

		return "item/list/item_list";
	}

	/**
	 * 新着一覧
	 *
	 */
	@RequestMapping(path = "/item/list")
	public String top(Model model, HttpSession session, Pageable pageable) {
		Page<Item> itemList = itemRepository.findByDeleteFlagOrderByInsertDateDesc(Constant.NOT_DELETED, pageable);

		List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList.getContent());

		model.addAttribute("pages", itemList);
		model.addAttribute("items", itemBeanList);
		model.addAttribute("url", "/item/list/");

		model.addAttribute("sortType", 1);

		session.setAttribute("search", 0);

		return "item/list/item_list";
	}

	@RequestMapping(path = "/item/list/{sortType}")
	public String topIndex(@PathVariable int sortType, Model model, HttpSession session, Pageable pageable) {
		int search = (int) session.getAttribute("search");

		if (search == 1) {

			if (sortType == 1) {
				Page<Item> itemList = (Page<Item>) session.getAttribute("items");

				List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList.getContent());

				model.addAttribute("pages", itemList);
				model.addAttribute("items", itemBeanList);
				model.addAttribute("url", "/item/list/");

			} else if (sortType == 2) {
				List<Integer> lists = orderItemRepository.findByIdOrderQuantityDescQuery();

				Page<Item> items = (Page<Item>) session.getAttribute("items");

				List<Integer> listId = new ArrayList<>();

				List<ItemBean> itemBeanList = (List<ItemBean>) session.getAttribute("itemBeans");

				for (int id : lists) {
					for (ItemBean bean : itemBeanList) {
						if (bean.getId() == id) {
							itemBeanList.remove(bean);
							listId.add(0, id);
							break;

						}
					}
				}

				for (int itemId : listId) {
					Item item = itemRepository.getOne(itemId);

					ItemBean bean = new ItemBean();

					bean.setId(item.getId());
					bean.setName(item.getName());
					bean.setPrice(item.getPrice());
					bean.setStock(item.getStock());
					bean.setImage(item.getImage());
					bean.setDescription(item.getDescription());
					bean.setCategoryId(item.getCategory().getId());
					bean.setCategoryName(item.getCategory().getName());

					itemBeanList.add(0, bean);
				}

				model.addAttribute("pages", items);
				model.addAttribute("items", itemBeanList);
				model.addAttribute("url", "/item/list/");

			}

		} else {

			if (sortType == 1) {
				Page<Item> itemList = itemRepository.findByDeleteFlagOrderByInsertDateDesc(Constant.NOT_DELETED,
						pageable);

				List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(itemList.getContent());

				model.addAttribute("pages", itemList);
				model.addAttribute("items", itemBeanList);
				model.addAttribute("url", "/item/list/");

			} else if (sortType == 2) {
				List<Integer> lists = orderItemRepository.findByIdOrderQuantityQuery();

				Page<Item> items = itemRepository.findByDeleteFlagOrderByInsertDateDesc(Constant.NOT_DELETED, pageable);

				model.addAttribute("items", items);

				List<ItemBean> itemBeanList = BeanCopy.copyEntityToItemBean(items.getContent());

				for (int id : lists) {
					for (ItemBean bean : itemBeanList) {
						if (bean.getId() == id) {
							itemBeanList.remove(bean);
							break;
						}
					}
				}

				for (int itemId : lists) {
					Item item = itemRepository.getOne(itemId);

					ItemBean bean = new ItemBean();
					bean.setId(item.getId());
					bean.setName(item.getName());
					bean.setPrice(item.getPrice());
					bean.setStock(item.getStock());
					bean.setImage(item.getImage());
					bean.setDescription(item.getDescription());
					bean.setCategoryId(item.getCategory().getId());
					bean.setCategoryName(item.getCategory().getName());

					itemBeanList.add(0, bean);
				}

				model.addAttribute("pages", items);
				model.addAttribute("items", itemBeanList);
				model.addAttribute("url", "/item/list/");

			}
		}
		return "item/list/item_list";
	}

}
