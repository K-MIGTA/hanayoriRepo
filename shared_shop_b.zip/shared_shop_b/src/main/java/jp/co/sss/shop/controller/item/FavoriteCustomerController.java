package jp.co.sss.shop.controller.item;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.bean.FavoriteBean;
import jp.co.sss.shop.bean.UserBean;
import jp.co.sss.shop.entity.Favorite;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.entity.User;
import jp.co.sss.shop.repository.FavoriteRepository;
import jp.co.sss.shop.repository.ItemRepository;
import jp.co.sss.shop.repository.UserRepository;
import jp.co.sss.shop.util.Constant;

/**
 *
 *
 * @author 花より漢気
 */

@Controller
public class FavoriteCustomerController {

	/**
	 * お気に入り情報
	 */
	@Autowired
	FavoriteRepository favoriteRepository;

	/**
	 * 商品情報
	 */
	@Autowired
	ItemRepository itemRepository;

	/**
	 * 会員情報
	 */
	@Autowired
	UserRepository userRepository;

	/**
	 * セッション管理
	 */
	@Autowired
	HttpSession session;

	/**
	 * ナビゲーションバーから画面遷移
	 *
	 * @param model    Viewとの値受渡し
	 * @param pageable ページング情報
	 * @return "item/favorite/favorite_list" お気に入り一覧画面へ
	 */
	@RequestMapping(path = "/item/favorite", method = RequestMethod.GET)
	public String index(Model model, Pageable pageable) {

		// ログイン中の会員情報を取得
		UserBean userBean = (UserBean) session.getAttribute("user");

		User user = userRepository.getOne(userBean.getId());

		Page<Favorite> favorites = favoriteRepository.findByUserIdAndDeleteFlag(user, Constant.NOT_DELETED, pageable);

		List<FavoriteBean> favoriteList = new ArrayList<>();

		for (Favorite fav : favorites) {

			// 商品IDに該当する商品情報を取得
			Item item = itemRepository.getOne(fav.getItemId().getId());

			FavoriteBean favoriteBean = new FavoriteBean();

			favoriteBean.setId(item.getId());
			favoriteBean.setName(item.getName());
			favoriteBean.setPrice(item.getPrice());
			favoriteBean.setImage(item.getImage());
			favoriteBean.setCategory(item.getCategory().getName());

			favoriteList.add(favoriteBean);
		}

		model.addAttribute("pages", favorites);
		model.addAttribute("favorites", favoriteList);
		model.addAttribute("url", "/item/favorite/");

		return "item/favorite/favorite_list";

	}

	/**
	 * お気に入り追加
	 */
	@RequestMapping(path = "/favorite/addition", method = RequestMethod.POST)
	public String favoliteAdd(int id, Model model, Pageable pageable) {

		// ログイン中の会員情報を取得
		UserBean userBean = (UserBean) session.getAttribute("user");

		// 商品IDに該当する商品情報を取得
		Item item = itemRepository.getOne(id);

		User user = userRepository.getOne(userBean.getId());

		Favorite favorite = favoriteRepository.findByUserIdAndItemId(user, item);

		//	お気に入りに重複する商品がない時
		if (favorite == null) {

			favorite = new Favorite();

			favorite.setItemId(item);
			favorite.setUserId(user);

		} else {

			favorite.setDeleteFlag(Constant.NOT_DELETED);

		}

		favoriteRepository.save(favorite);

		return "redirect:/item/detail/" + id;
	}

	/**
	 * お気に入り削除
	 */
	@RequestMapping(path = "/favorite/delete", method = RequestMethod.POST)
	public String favoliteDel(int id, Model model, Pageable pageable) {

		// ログイン中の会員情報を取得
		UserBean userBean = (UserBean) session.getAttribute("user");

		Item item = itemRepository.getOne(id);

		User user = userRepository.getOne(userBean.getId());

		// お気に入り情報を取得
		Favorite favorite = favoriteRepository.findByUserIdAndItemId(user, item);

		// 削除フラグを立てる
		favorite.setDeleteFlag(Constant.DELETED);

		// お気に入り情報を保存
		favoriteRepository.save(favorite);

		return "redirect:/item/detail/" + id;
	}

	@RequestMapping(path = "/favorite/delete", method = RequestMethod.GET)
	public String favoliteDel2(int id, Model model, Pageable pageable) {

		// ログイン中の会員情報を取得
		UserBean userBean = (UserBean) session.getAttribute("user");

		Item item = itemRepository.getOne(id);

		User user = userRepository.getOne(userBean.getId());

		// お気に入り情報を取得
		Favorite favorite = favoriteRepository.findByUserIdAndItemId(user, item);

		// 削除フラグを立てる
		favorite.setDeleteFlag(Constant.DELETED);

		// お気に入り情報を保存
		favoriteRepository.save(favorite);

		return "redirect:/item/favorite";
	}
}
