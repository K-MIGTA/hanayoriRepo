package jp.co.sss.shop.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.sss.shop.entity.Inqueries;
import jp.co.sss.shop.repository.InqueriesRepository;

/**
 * お問い合わせ詳細表示(運用管理者・システム管理者)
 *
 * @author 花より漢気
 */

@Controller
public class ContactDetailsController {

	@Autowired
	private InqueriesRepository inqueriesRepository;

	@RequestMapping(path = "user/contact/detail/{id}")
	public String showContact(@PathVariable int id, Model model) {

		Inqueries inqueries = inqueriesRepository.findById(id).orElse(null);

		model.addAttribute("inqueries", inqueries);

		return "user/contact/details/user_contact_details";
	}

}