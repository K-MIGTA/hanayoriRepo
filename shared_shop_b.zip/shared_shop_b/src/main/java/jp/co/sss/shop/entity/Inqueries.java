package jp.co.sss.shop.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "inqueries")

public class Inqueries {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_inqueries_gen")
	@SequenceGenerator(name = "seq_inqueries_gen", sequenceName = "seq_inqueries", allocationSize = 1)
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "contact_category", referencedColumnName = "id")
	private Questions questions;

	@Column
	private String text;

	@Column(insertable = false)
	private Date sendDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getSendDate() {
		return sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	public Questions getQuestions() {
		return questions;
	}

	public void setQuestions(Questions questions) {
		this.questions = questions;
	}

}