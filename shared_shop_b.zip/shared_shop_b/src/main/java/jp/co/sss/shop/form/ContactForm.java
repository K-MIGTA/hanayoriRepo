package jp.co.sss.shop.form;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * お問い合わせ入力フォーム
 *
 * @author SystemShared
 */
public class ContactForm {

	/**
	 * お問い合わせ種類番号
	 */
	private Integer id;
	
	/**
	 * お問い合わせ種類
	 */
	private String name;

	/**
	 * お問い合わせ内容
	 */
	@NotBlank
	@Size(min = 1, max = 150)
	private String text;

	private Date sendDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getSendDate() {
		return sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

}