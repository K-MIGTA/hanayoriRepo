package jp.co.sss.shop.controller.basket;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.bean.BasketBean;
import jp.co.sss.shop.entity.Item;
import jp.co.sss.shop.repository.ItemRepository;

/**
 * 買い物かご機能のコントローラクラス
 *
 * @author 花より漢気
 */
@Controller
public class BasketCustomerController {

	/**
	 * 商品追加
	 */
	@Autowired
	ItemRepository itemRepository;
	@Autowired
	HttpSession session;

	@RequestMapping(path = "/basket/add", method = RequestMethod.POST)
	public String addItem(Model model, int id) {

		Item item = itemRepository.getOne(id);
		BasketBean bean = new BasketBean(item.getId(), item.getName(), item.getStock());

		//左商品ID 右arrayListの番号 session.getAttributeでmaplistを呼び出してる
		Map<Integer, Integer> map = (Map<Integer, Integer>) session.getAttribute("mapList");

		//session.getAttributeでbasketを呼び出してる  session.getAttribute("basket") オブジェクト型からlist型に変更
		List<BasketBean> basketItem = (List<BasketBean>) session.getAttribute("basket");

		//買い物かごがない時
		if (basketItem == null) {

			//買い物かご生成
			basketItem = new ArrayList<>();
			map = new HashMap<>();

			//商品追加
		} else if (map.get(item.getId()) != null) {
			bean.setOrderNum(basketItem.get(map.get(item.getId())).getOrderNum() + 1); //商品追加
		}

		//商品の在庫数がゼロの時
		if (item.getStock() == 0) {
			model.addAttribute("flag", 0);
			model.addAttribute("item", item);
			return basketListGet(model);

		} else if (item.getStock() < bean.getOrderNum()) { //注文数が在庫数より多い時
			model.addAttribute("flag", 1);
			model.addAttribute("item", item);
			return basketListGet(model);

		} else if (map.get(item.getId()) == null) { //商品を買い物かごに入れるとき
			basketItem.add(bean);
			map.put(item.getId(), basketItem.size() - 1);
			session.setAttribute("basket", basketItem); //セッションスコープに保存
			session.setAttribute("mapList", map); //セッションスコープに保存
			//System.out.println(map.toString()); //実行しているのか確認用と値の代入が正しいのか

		} else {
			basketItem.set(map.get(item.getId()), bean);
			session.setAttribute("basket", basketItem); //セッションスコープに保存
			session.setAttribute("mapList", map); //セッションスコープに保存
		}

		return "redirect:/basket/list";
	}

	/*
	 * 削除ボタン
	 */
	@RequestMapping(path = "/basket/delete", method = RequestMethod.POST)
	public String basketDelete(Model model, int id) {
		Map<Integer, Integer> map = (Map<Integer, Integer>) session.getAttribute("mapList");
		List<BasketBean> basketItem = (List<BasketBean>) session.getAttribute("basket");

		Item item = itemRepository.getOne(id);
		BasketBean bean = basketItem.get(map.get(item.getId()));

		if (bean.getOrderNum() >= 2) {

			bean.setOrderNum(bean.getOrderNum() - 1); //注文個数を一つ減らす
			basketItem.set(map.get(item.getId()), bean);

		} else {
			basketItem.remove(basketItem.get(map.get(item.getId())));
			map.clear();
			for (int i = 0; i < basketItem.size(); i++) {
				map.put(basketItem.get(i).getId(), i);
			}
		}

		model.addAttribute("baskets", basketItem);
		return "redirect:/basket/list";
	}

	/*
	 * 買い物かごをすべて空にする時の処理
	 */
	@RequestMapping(path = "/basket/allDelete", method = RequestMethod.POST)
	public String deleteAll(Model model) {
		Map<Integer, Integer> map = (Map<Integer, Integer>) session.getAttribute("mapList");
		List<BasketBean> basketItem = (List<BasketBean>) session.getAttribute("basket");

		model.addAttribute("baskets", basketItem);
		basketItem.clear();
		map.clear();
		return "redirect:/basket/list";
	}

	/*
	 * forward:/basket/listのURLをもらった時の処理
	 */
	@RequestMapping(path = "/basket/list", method = RequestMethod.POST)
	public String basketList(Model model) {

		Map<Integer, Integer> map = (Map<Integer, Integer>) session.getAttribute("mapList");
		List<BasketBean> basketItem = (List<BasketBean>) session.getAttribute("basket");

		model.addAttribute("baskets", basketItem);
		//System.out.println("test" + basketItem.toString());
		return "basket/shopping_basket";
	}

	/*
	 * ナビゲーションから画面遷移
	 */
	@RequestMapping(path = "/basket/list", method = RequestMethod.GET)
	public String basketListGet(Model model) {
		Map<Integer, Integer> map = (Map<Integer, Integer>) session.getAttribute("mapList");
		List<BasketBean> basketItem = (List<BasketBean>) session.getAttribute("basket");
		if (basketItem == null) {

			//買い物かご生成
			basketItem = new ArrayList<>();
			map = new HashMap<>();
		}

		//商品を買い物かごに追加順
		List<BasketBean> basketSize = new ArrayList<>();

		for (int i = basketItem.size(); 0 < i; i--) {
			basketSize.add(basketItem.get(i - 1));
		}

		model.addAttribute("baskets", basketSize);
		//System.out.println("test" + basketItem.toString());
		return "basket/shopping_basket";
	}

}
