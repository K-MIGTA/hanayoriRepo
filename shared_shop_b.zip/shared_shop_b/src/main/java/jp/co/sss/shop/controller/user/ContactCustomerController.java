package jp.co.sss.shop.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jp.co.sss.shop.entity.Inqueries;
import jp.co.sss.shop.repository.InqueriesRepository;

/**
 * お問い合わせ一覧表示(運用管理者・システム管理者)
 *
 * @author 花より漢気
 */

@Controller
public class ContactCustomerController {

	@Autowired
	InqueriesRepository inqueriesRepository;

	@RequestMapping(path = "/user/contact/list", method = RequestMethod.GET)
	public String contactListByOrderByIdDesc(Model model, Pageable pageable) {
		Page<Inqueries> inqueriesList = inqueriesRepository.findAllByOrderByIdDesc(pageable);

		model.addAttribute("pages", inqueriesList);
		model.addAttribute("inqueries", inqueriesList.getContent());
		model.addAttribute("url", "/user/contact/list");

		return "user/contact/list/user_contact_list";
	}

}